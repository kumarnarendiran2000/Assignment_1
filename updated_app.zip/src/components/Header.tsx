import React from 'react';
import { Link } from 'react-router-dom';
import useStore from '../store/useStore';

const Header: React.FC = () => {
  const setCurrentPage = useStore((state) => state.setCurrentPage);

  return (
    <header className="bg-blue-500 text-white p-4 flex justify-between items-center">
      <h1 className="text-2xl font-bold">My Cool Website</h1>
      <nav>
        <Link to="/" className="mx-4" onClick={() => setCurrentPage('Home')}>Home</Link>
        <Link to="/about" className="mx-4" onClick={() => setCurrentPage('About')}>About</Link>
        <Link to="/contact" className="mx-4" onClick={() => setCurrentPage('Contact')}>Contact</Link>
      </nav>
    </header>
  );
};

export default Header;
