import React from 'react';

const Contact: React.FC = () => {
  return (
    <div className="p-8 bg-white shadow-md rounded-lg">
      <h2 className="text-2xl font-bold mb-4">Contact Us</h2>
      <p className="text-gray-700">This is the contact page content.</p>
    </div>
  );
};

export default Contact;
