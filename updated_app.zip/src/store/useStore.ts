import create from 'zustand';

interface StoreState {
  isLoggedIn: boolean;
  setLoggedIn: (loggedIn: boolean) => void;
}

const useStore = create<StoreState>((set) => ({
  isLoggedIn: false,
  setLoggedIn: (loggedIn) => set({ isLoggedIn: loggedIn }),
}));

export default useStore;
